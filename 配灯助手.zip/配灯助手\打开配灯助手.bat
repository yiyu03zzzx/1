@echo off
chcp 65001 >nul
title 配灯助手
set "F=%~dp0index.html"
if not exist "%F%" (
  echo 没找到 index.html，请把这个 bat 和 index.html 放在同一个文件夹里。
  pause
  exit /b
)
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "CHROME86=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "CHROMEL=%LocalAppData%\Google\Chrome\Application\chrome.exe"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "EDGE2=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if exist "%CHROME%"   ( start "" "%CHROME%" "%F%" & exit /b )
if exist "%CHROME86%" ( start "" "%CHROME86%" "%F%" & exit /b )
if exist "%CHROMEL%"  ( start "" "%CHROMEL%" "%F%" & exit /b )
if exist "%EDGE2%"    ( start "" "%EDGE2%" "%F%" & exit /b )
if exist "%EDGE%"     ( start "" "%EDGE%" "%F%" & exit /b )

echo 没找到 Chrome 或 Edge，正在用系统默认程序打开……
start "" "%F%"
